module.exports = {
  plugins: [
    require('autoprefixer'),
    require('postcss-import'),
    require('precss'),
    require('lost'),
    require('postcss-reporter'),
  ]
}