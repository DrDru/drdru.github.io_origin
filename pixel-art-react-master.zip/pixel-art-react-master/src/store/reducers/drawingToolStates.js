export const PENCIL = 'PENCIL';
export const ERASER = 'ERASER';
export const BUCKET = 'BUCKET';
export const MOVE = 'MOVE';
export const EYEDROPPER = 'EYEDROPPER';
export const COLOR_PICKER = 'COLOR_PICKER';
