import 'canvas-toBlob';
import 'whatwg-fetch';
