This repository houses data that is used on, by, or for http://nihongoresources.com and
affiliated websites, as a convenient online place. Eventually this will be data, scripts,
and other things relating to NR and the book that NR turned into, but for now it's not
all too many files yet.

 - giongo.txt: a plain text version of the data backing the giongo/gitaigo (onomatopoeic data) on NR
 - pdict: the particles dictionary, in XML format
 - radical.utf8.txt: the traditional 214 indexing radicals (With variations)

- Pomax
